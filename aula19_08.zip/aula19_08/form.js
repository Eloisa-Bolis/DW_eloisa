let form1 = document.getElementById('form1');
form1.addEventListener('submit', validaform);       //quando clicar em enviar ativa o função validaform

function validaform(event){
    if((validanome()==false)|| (validaend() == false)){            //se não tiver nome
        event.preventDefault();         //cancela o envio
        alert('Analfabeto digita certo >:|');
    } else {
        alert('Parabéns vc não é um inultil :)')
    }
}

function validanome(){
    let nome = document.getElementById('nome');     //pega o nome
    if(nome.value.length==0){                       //pega o valor e ve se o tamanho for = 0
        nome.setAttribute('class', 'erro');
        return false;
    } else {
        nome.setAttribute('class', 'correto');      //não funciona
        return true;
    }                
}

function validaend(){
    let end = document.getElementById('end');
    if(end.value.length==0){
        end.setAttribute('class', 'erro');
        return false;
    } else {
        end.setAttribute('class', 'correto');
        return true;
    }
}